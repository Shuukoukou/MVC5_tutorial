﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace GrepAplication
{
    class GrepFile
    {
        public string OutPutConsole(string path, string searchWord)
        {
            string result = "";

            var enc = Encoding.GetEncoding("Shift_JIS");
            result = OutPutConsole(path, searchWord, enc);

            enc = Encoding.GetEncoding("utf-8");
            result = result + OutPutConsole(path, searchWord, enc);

            return result;

        }

        private string OutPutConsole(string path, string searchWord, Encoding enc)
        {
            string result = "";

            Regex reg = new Regex(searchWord);

            StreamReader cReader = (new StreamReader(@path, enc));
            int lineCount = 0;

            while (cReader.Peek() >= 0) // 読み込みできる文字がなくなるまで繰り返す
            {
                string stBuffer = cReader.ReadLine();
                lineCount++;

                if (reg.IsMatch(stBuffer))
                {
                    result = result + ("!!Find !! " + path + " 行番号:" +lineCount+"\n");
                }
            }

            cReader.Close();
            return result;
        }
    }
}
