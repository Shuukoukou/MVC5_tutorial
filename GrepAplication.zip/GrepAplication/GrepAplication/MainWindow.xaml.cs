﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.IO;
using System.Diagnostics;
using System.Windows.Threading;

using Microsoft.WindowsAPICodePack.Dialogs;
using System.Text.RegularExpressions;


namespace GrepAplication
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void runButton_Click(object sender, RoutedEventArgs e)
        {
            resultTextBox.Text = ""; //画面をリフレッシュ

            var path = pathTextBox.Text;

            if (!System.IO.Directory.Exists(path)) //Directoryとファイルで参照するクラスが違うので要注意 
            {                
                resultTextBox.Text = ("エラー！！  パスは存在するものを入力してください");
                return;
            }


            statusLabel.Content = "サブフォルダがアクセス可能か調べています(たくさんだと時間がかかります)";
            DoEvents();

            //サブフォルダがアクセス可能かチェックしつつパスを取得 ---
            List<string> subFolders = new List<string>();

            FolderInsiteSarch FIS = new FolderInsiteSarch();
            int n = 1;
            int folderCount = FIS.doSearch(path, subFolders,ref n);

            StringComparer cmp = StringComparer.OrdinalIgnoreCase;
            subFolders.Sort(cmp);
            //-------------------------------------------------------


            // 検索文字がNullか空白でなければ検索するフラグを立てる -----------------------------
            string searchWord = searchWordTextBox.Text;
            bool grepFlg = false;

            if (!searchWord.Equals("") || !string.IsNullOrEmpty(searchWord))
            {
                grepFlg = true;
            }
            //---------------------------------------------

            
            bool isSubFoldersDisplayOut = subPathDisplayFlgCheckBox.IsChecked.GetValueOrDefault();    // サブフォルダを表示 のチェックboxを参照 -----

            bool isListAllFilesCB = listAllFilesCB.IsChecked.GetValueOrDefault();           // ファイル名を表示 のチェックboxを参照 -----

            // ファイル名を検索 のチェックboxを参照 -------------------------
            bool isSeaechForFilenameCB = searchForFilenameCB.IsChecked.GetValueOrDefault();

            if (isSeaechForFilenameCB)
            {
                grepFlg = false;
            }
            if (searchWord.Equals("") || string.IsNullOrEmpty(searchWord))
            {
                isSeaechForFilenameCB = false;  //文字が空だった場合はファイル名を検索フラグを下げておく
            }
            // ------------------------------------------------------------


            // バックスラッシュの数=階層 ------------------ 
            int rootDirHier = CountChar(path, "\\");
            int beforeDirHier = rootDirHier;

            try
            {
                
                string result = path + "\n";  // 検索結果を入れておくバッファ
                int nowCount = 0;             // 調べ終わったフォルダのカウント数

                //フォルダ名を表示する。階層の深さで前方に空白を入れる。
                foreach (string subFolder in subFolders)
                {
                    nowCount++;
                    statusLabel.Content = "searched at " + nowCount.ToString() + "/" + folderCount.ToString() + " folders done.";
                    DoEvents();

                    string s = subFolder;

                    int nowDirHier = CountChar(s, "\\");
                    string repeatedString = new string(' ', (nowDirHier - rootDirHier)); //繰り返し文字列

                    if (isSubFoldersDisplayOut) //サブフォルダ表示がON
                    {
                        //上の階層に戻ったので改行を入れる
                        if (nowDirHier < beforeDirHier)
                        {
                            result = result + ("\n");
                        }

                        result = result + (repeatedString + "┗" + s + "\n");
                    }

                    if (grepFlg)
                    {
                        foreach (var f in Directory.GetFiles(subFolder, "*.*", SearchOption.TopDirectoryOnly))
                        {
                            GrepFile GF = new GrepFile();    //ループの中でインスタンス呼ぶのは大丈夫っぽい
                            result = result + GF.OutPutConsole(f, searchWord); // GrepFileへ飛ぶ
                        }
                    }

                    if (isListAllFilesCB | isSeaechForFilenameCB)
                    {
                        string[] files = System.IO.Directory.GetFiles(subFolder, "*.*", SearchOption.TopDirectoryOnly).Select(x => System.IO.Path.GetFileName(x)).ToArray();
                        foreach (string f in files)
                        {
                            if (isSeaechForFilenameCB)
                            {

                                Regex reg = new Regex(searchWord);
                                if (reg.IsMatch(f))
                                {
                                    result = result + repeatedString + "! FileNameFind !  - " + f + "\n";
                                }
                            }

                            if (isListAllFilesCB)
                            {
                                result = result + repeatedString + "    - " + f + "\n";
                            }

                        }

                    }
                    
                    //結果をテキストボックスに追記して、クリア (これやっておかないと文字数でオーバーフローする
                    resultTextBox.AppendText(result);
                    result = "";

                    //前回階層を現在の階層に更新して次のフォルダへ
                    beforeDirHier = nowDirHier;
                
                }
                nowCount++;
                statusLabel.Content = "searched at " + nowCount.ToString() + "/" + folderCount.ToString()+ " folders done. Finished!!";


            }
            catch (Exception ex)
            {
                resultTextBox.Text = "";
                Show(ex);

            }
        }

        public static int CountChar(string s, string c)
        {
            return s.Length - s.Replace(c.ToString(), "").Length;
        }

        static void Show(Exception ex)
        {
            Debug.WriteLine("message: " + ex.Message);
            Debug.WriteLine("stack trace: ");
            Debug.WriteLine(ex.StackTrace);
            Debug.WriteLine("\n");
        }

        /// これを呼ぶと画面が更新される
        private void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            var callback = new DispatcherOperationCallback(obj =>
            {
                ((DispatcherFrame)obj).Continue = false;
                return null;
            });
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, callback, frame);
            Dispatcher.PushFrame(frame);
        }

        private void folderSelectButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new CommonOpenFileDialog("参照フォルダ選択");
            // フォルダ選択モード。
            dlg.IsFolderPicker = true;
            var ret = dlg.ShowDialog();
            if (ret == CommonFileDialogResult.Ok)
            {
                pathTextBox.Text = dlg.FileName;
            }


        }
    }
}


