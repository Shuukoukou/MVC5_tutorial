﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace GrepAplication
{
    class SubFolderList
    {
        public string path { get; set; }

        public string outPut(string searchWord,bool isDisplayOut)
        {
            string result = path + "\n";

            //サブフォルダを探しに行く。ワイルドカード"*"は、すべてのフォルダを意味する
            string[] subFolders = System.IO.Directory.GetDirectories(path, "*", SearchOption.AllDirectories);


            //取得したString配列を大文字小文字を区別しない序数比較で並び替える
            StringComparer cmp = StringComparer.OrdinalIgnoreCase;
            Array.Sort(subFolders, cmp);


            //grepするかの判定 -----------------------------
            bool grepFlg = false;

            if (!searchWord.Equals("") || !string.IsNullOrEmpty(searchWord))
            {
                grepFlg = true;
            }
            //---------------------------------------------


            //バックスラッシュの数=階層
            int rootDirHier = CountChar(path, "\\");
            int beforeDirHier = rootDirHier;


            //フォルダ名を表示する。階層の深さで前方に空白を入れる。
            foreach (string subFolder in subFolders)
            {
                string s = subFolder;

                int nowDirHier = CountChar(s, "\\");
                string repeatedString = new string(' ', (nowDirHier - rootDirHier)); //繰り返し文字列

                if (isDisplayOut) //フォルダはcheckBoxがONの時だけ表示
                {
                    //上の階層に戻ったので改行を入れる
                    if (nowDirHier < beforeDirHier)
                    {
                        result = result + ("\n");
                    }

                    result = result + (repeatedString + "┗" + s + "\n");
                }

                //SubFolder内のファイルを取得してGrepに飛ばす
                if (grepFlg)
                {
                    foreach (var f in Directory.GetFiles(subFolder, "*.*"
                            , SearchOption.TopDirectoryOnly))
                    {
                        GrepFile GF = new GrepFile();    //ループの中でインスタンス呼ぶのは大丈夫っぽい
                        result = result + GF.OutPutConsole(f, searchWord); // GrepFileへ飛ぶ
                    }
                }

                //前回階層を現在の階層に更新して次のフォルダへ
                beforeDirHier = nowDirHier;
            }

            return result;
        }

        public static int CountChar(string s, string c)
        {
            return s.Length - s.Replace(c.ToString(), "").Length;
        }

    }
}
