﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace GrepAplication
{
    class FolderInsiteSarch
    {
        public int doSearch(string folderPath, List<string> list,ref int count)
        {
            
            try
            {

                //現在のフォルダ内のすべてのフォルダパスを取得
                var dirNames = Directory.EnumerateDirectories(folderPath);

                count = count + 1;
                list.Add(folderPath);

                //フォルダがないならば再帰探索終了し、あるなら各フォルダに対して探索実行
                if (dirNames.Count() == 0)
                {
                    return 0;
                }
                else
                {
                    foreach (var dirName in dirNames)
                    {
                        Debug.WriteLine(dirName);
                        doSearch(dirName, list,ref count); //再帰
                       
                    }
                }
                return count;

            }
            catch (UnauthorizedAccessException ex)
            {
                Debug.WriteLine("例外でござる！！");
                Debug.WriteLine(ex);
                //return;
                return 0;
            }

        }    

    }
}
